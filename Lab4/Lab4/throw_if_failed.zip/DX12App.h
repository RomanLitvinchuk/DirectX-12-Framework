#pragma once
#include <Windows.h>
#include <d3d12.h>
#include <DirectXHelpers.h>
#include <dxgi1_6.h>
#include <wrl.h>
#include <comdef.h>
#include <DescriptorHeap.h>
#include <d3dx12.h>
#include "game_timer.h"
#include "upload_buffer.h"
#include "object_constants.h"
#include "g_buffer.h"
#include "rendering_system.h"
#include "light.h"
#include "camera.h"
#include "octree.h"
#include "particle.h"
#include "shadow_map.h"
#include "ssao.h"
#include "scene_data.h"
#include "input_handler.h"
#include "frame_resource.h"


using Microsoft::WRL::ComPtr;
using namespace DirectX;

class DX12App
{
public:
	void Init(HWND hWnd);
	void OnResize();
	void CalculateGameStats(HWND hWnd);
	void Draw();
	void OnMouseDown(HWND hWnd);
	void OnMouseUp();
	void Update();
	void NewImGuiFrame();
	void BuildImGui();
	void ShutdownImGui();

	Camera& GetCamera()
	{ 
		return camera; 
	}

	GameTimer& GetTimer() 
	{ 
		return gt; 
	}

	bool IsDeviceCreated() 
	{ 
		return device != nullptr; 
	}

	D3D12_CPU_DESCRIPTOR_HANDLE GetBackBuffer() const;
	ID3D12Resource* CurrentBackBuffer() const;
	D3D12_CPU_DESCRIPTOR_HANDLE GetDSV() const;

	void SetClientWH(int newWidth, int newHeight) 
	{
		clientWidth = newWidth;
		clientHeight = newHeight;
	}

	bool keyStates[256] = { false };

	int GetClientWidth() { return clientWidth; }
	int GetClientHeight() { return clientHeight; }


private:
	void EnableDebug();
	void GetVisibleObjects();
	void DrawLOD0ToGBuffer(UINT& currentInstanceOffset, Submesh& sm);
	void DrawBakedMeshToGBuffer(UINT& currentInstanceOffset, Submesh& sm);
	void DrawLOD1ToGBuffer(UINT& currentInstanceOffset, Submesh& sm);
	void DrawBillboardsToGBuffer(UINT& currentInstanceOffset, Submesh& sm);
	void SortLODs();
	void TAAResolve();
	void DrawShadows();
	void DrawSSAO();
	void BlurSSAO();
	void DrawToGBuffer();
	void DrawLights();
	void DrawNYBalls();
	void DrawToStreamOutput();
	void DrawWireframe();
	void DrawParticles();
	void ComputeParticles();
	void EmitParticles();
	void InitEmitter();
	void DrawPPTonemap(MyTexture* readHDR);
	void DrawPPVignette(MyTexture* readLDR, MyTexture* writeLDR);
	void DrawPPOutput(MyTexture* readLDR);

	void UpdateParticleData();
	void UpdateMatricesData();
	void UpdatePrevMatricesData();
	void UpdateFrustumData();
	void UpdateTextureAnimation();
	void UpdateTreesLights();
	void UpdateShadowData();
	void UpdateHullBuffer();
	void UpdateObjectsBuffer();
	void UpdateCameraConstants();
	void UpdateViewportConstants();
	float Halton(uint32_t index, uint32_t base);

	void InitializeDevice();
	void CreateCommandQueue();
	void CreateCommandList();
	void CreateSwapChain(HWND hWnd);
	void CreateRTVAndDSVDescriptorHeaps();
	void CreateCBVDescriptorHeap();
	void CreateRTV();
	void CreateDSV();
	void LoadTextures();
	void CreateSRV();
	void CreateSamplerHeap();
	void CreateSOBuffers();
	void InitUAVBuffers();
	void CreateConstantBufferView();
	void CreateStructuredBuffersSRV();
	void SetViewport();
	void SetScissor();
	void InitProjectionMatrix();
	void CreateVertexBuffer();
	void CreateIndexBuffer();

	void InitFrameResources();
	void FillFrameResources();
	void WaitForCurrentFrameResource();
	void InitUploadBuffers();
	void FillUploadBuffers();

	void BuildBulbGeometry();
	void BuildBoxGeometry();
	void InitShadowMap();
	void InitRenderSystem();

	void Parsing();
	void BuildOctree();
	std::vector<Vector3> GetFrustumCornersWorldSpace(Matrix invViewProj);
	void UpdateCascades();



	void InitHistoryTextureFromCurrentFrame(MyTexture& copyTexture);

	void InitImGui(HWND hwnd);
	void RenderImGui();
	void CreateImGuiDescriptorHeap();

	void FlushCommandQueue();



	GameTimer gt;
	InputHandler inputHandler;
	DXGI_FORMAT backBufferFormat = DXGI_FORMAT_R8G8B8A8_UNORM;
	DXGI_FORMAT depthStencilFormat = DXGI_FORMAT_D24_UNORM_S8_UINT;
	int clientWidth = 1424;
	int clientHeight = 750;
	ComPtr<IDXGIFactory4> DXGIFactory = nullptr;
	ComPtr<ID3D12Device> device = nullptr;
	ComPtr<ID3D12Fence> fence;
	UINT64 currentFence = 0;
	UINT rtvDescriptorSize = 0;
	UINT dsvDescriptorSize = 0;
	UINT cbvDescriptorSize = 0;
	D3D12_FEATURE_DATA_MULTISAMPLE_QUALITY_LEVELS msQualityLevels_;
	
	ComPtr<ID3D12CommandQueue> commandQueue = nullptr;
	ComPtr<ID3D12GraphicsCommandList> commandList = nullptr;
	
	ComPtr<IDXGISwapChain> swapChain = nullptr;

	ComPtr<ID3D12DescriptorHeap> rtvHeap = nullptr;
	ComPtr<ID3D12DescriptorHeap> dsvHeap = nullptr;
	ComPtr<ID3D12DescriptorHeap> cbvSrvHeap = nullptr;
	ComPtr<ID3D12DescriptorHeap> uavHeap = nullptr;
	ComPtr<ID3D12DescriptorHeap> samplerHeap = nullptr;
	ComPtr<ID3D12DescriptorHeap> imGuiSrvHeap = nullptr;
	static constexpr UINT IMGUI_DESCRIPTOR_COUNT = 64;
	int currentBackBuffer = 0;

	ComPtr<ID3D12Resource> swapChainBuffer[2];
	ComPtr<ID3D12Resource> dsvBuffer = nullptr;

	D3D12_VIEWPORT viewport;
	D3D12_RECT scissorRect;

	ComPtr<ID3D12Resource> vertexBufferGPU = nullptr;
	ComPtr<ID3D12Resource> vertexBufferUploader = nullptr;
	D3D12_VERTEX_BUFFER_VIEW vertexBuffers[1];

	ComPtr<ID3D12Resource> indexBufferGPU = nullptr;
	ComPtr<ID3D12Resource> indexBufferUploader = nullptr;
	D3D12_INDEX_BUFFER_VIEW indexBufferView;

	static constexpr int numFrameResources = 3;
	std::vector<std::unique_ptr<FrameResource>> frameResources;
	FrameResource* currentFrameResource = nullptr;
	int currentFrameResourceIndex = 0;

	std::unique_ptr<UploadBuffer<uint32_t>> deadParticlesListUpload = nullptr;
	ComPtr<ID3D12Resource> RWParticleBuffer = nullptr;
	ComPtr<ID3D12Resource> ParticleDeadList = nullptr;
	ComPtr<ID3D12Resource> ParticleSortList = nullptr;
	ComPtr<ID3D12Resource> deadParticlesCounterBuffer = nullptr;
	ComPtr<ID3D12Resource> sortParticlesCounterBuffer = nullptr;
	const UINT PARTICLE_COUNT = 16384;
	std::vector<Particle> particles;
	Emitter emitter;


	std::vector<MeshInstanceData> instances;

	POINT mouseLastPos;
	Camera camera;
	BVH octree;

	std::vector<UINT> visibleIndices;
	bool bIsTreeVisible;

	std::vector<int> meshesMaterialIndex;

	SceneData sceneData;

	const float LOD_DISTANCE = 600.0f * 600.0f;
	const float BILLBOARD_DISTANCE = 900.0f * 900.0f;

	Submesh streamOutputMesh;
	ComPtr<ID3D12Resource> defaultTexture;
	std::vector<std::string> materialNames;

	RenderingSystem* renderSystem = nullptr;

	ComPtr<ID3D12Resource> sphereVertexBuffer = nullptr;
	ComPtr<ID3D12Resource> sphereIndexBuffer = nullptr;
	D3D12_VERTEX_BUFFER_VIEW sphereVertexBufferView;
	D3D12_INDEX_BUFFER_VIEW sphereIndexBufferView;
	UINT sphereIndexCount = 0;

	ComPtr<ID3D12Resource> wireframeVertexBuffer = nullptr;
	ComPtr<ID3D12Resource> wireframeIndexBuffer = nullptr;
	D3D12_VERTEX_BUFFER_VIEW wireframeVertexBufferView;
	D3D12_INDEX_BUFFER_VIEW wireframeIndexBufferView;

	ComPtr<ID3D12Resource> streamOutputBuffer = nullptr;
	ComPtr<ID3D12Resource> filledSizeBuffer = nullptr;
	ComPtr<ID3D12Resource> readbackBuffer = nullptr;
	D3D12_STREAM_OUTPUT_BUFFER_VIEW streamOutputBufferView = {};
	bool bIsFirstFrame = true;
	bool bHistoryValid = false;
	uint32_t frameIndex = 0;

	std::unique_ptr<ShadowMap> shadowMap;
	float SHADOW_MAP_SIZE = 8192.0f;
	CascadeData cascades;
};
